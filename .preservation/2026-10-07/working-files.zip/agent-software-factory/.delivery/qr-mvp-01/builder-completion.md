# Original builder completion — QR-MVP-01

Native primary builder: `/root/builder`. Native UI implementation helper:
`/root/builder/ui`. Neither is the independent verifier. Loaded instructions:
`AGENTS.md`, `.agents/skills/factory-delivery/SKILL.md`, `docs/ASF-MVP-01.md`,
and `.delivery/qr-mvp-01/requirements.md`.

Implemented `products/quantum-readiness/`, one new dedicated CI workflow, and a
minimal root README link. Existing Factory instructions/workflow are unchanged.
No commit, push, PR creation, customer scan, deployment, paid service or merge was
performed by the builder. Source is handed to the lead for establishing an exact
candidate and a different native verifier.

## Original final checks

- `node --test --test-concurrency=1 test/*.test.mjs`: **16/16 passed**, exit 0,
  tool chunk `8e6cca`. Complete original output: `builder-tests-final.txt`.
- `node scripts/browser-check.mjs`, Edge selected by `QR_BROWSER_EXECUTABLE`:
  **12/12 passed**, exit 0, tool chunk `b7ef87`. Complete original output:
  `builder-browser-final.txt`. Four reports came from real task-owned local TLS
  handshakes; hostile response rendering is explicitly labelled as mocked.
- Existing Factory syntax/discovery checks and all 13 product JS/MJS syntax checks
  passed, exit 0, tool chunk `778876`: `builder-static-final.txt`.
- Runtime: Node 24.19.0, OpenSSL 3.5.7, installed Playwright 1.62.1, local Edge.
  CI is configured for current Node 24 and Playwright Chromium, to be verified on
  the exact candidate by the lead rather than claimed from local results.

## Measured behavior and artifacts

- Real classical fixture: validated TLS 1.3, measured `X25519`; hybrid-only offer
  receives `bounded-negative`, leaving profile coverage incomplete.
- Real hybrid-capable fixture: validated TLS 1.3, actual `TLSGroup` named
  `X25519MLKEM768`; separate RSA certificate public key, decimal public exponent,
  and `sha256WithRSAEncryption` certificate signature metadata.
- Wrong-host certificate: both probes return `certificate-error` with
  `ERR_TLS_CERT_ALTNAME_INVALID`, and no falsely inferred group or clean result.
- Silent fixture: two bounded timeout observations. Additional real probes prove
  untrusted-chain rejection, encrypted-byte limits, and abort cancellation.
- Public boundary tests show absent permission and unsafe destinations make no
  connection, A/AAAA validation, canceled DNS deadlines, two numeric pinned probes
  without re-resolution, strict Host/Origin/CSRF, delayed-body concurrency,
  malicious output escaping, timed retention and attempt caps.
- JSON and HTML exports preserve original observations, scope and versioned dated
  rule sources. Each finding contains traceable observations, priority rationale,
  action, responsible party, dependencies, validation and rollback considerations.

Non-secret generated artifact paths:

- `products/quantum-readiness/.artifacts/controlled-reports.json`
- `products/quantum-readiness/.artifacts/browser-check.json`
- `products/quantum-readiness/.artifacts/browser-demo.png`
- `products/quantum-readiness/.artifacts/browser-report.png`
- `products/quantum-readiness/.artifacts/browser-mobile.png`

Full original failure/fix trail is in `builder-failures.md`, with the first-suite
output in `builder-tests-first.txt` and successful recheck in
`builder-tests-recheck.txt`. Helper original result/logs are in `builder-ui-*`.

## Important limits

No live public/customer target was assessed. Controlled harness endpoints are
loopback, fixed and explicitly labelled; production offers no private-address
bypass. The source is a trusted-local-operator pilot, not public self-service.
Evidence covers one address, two TLS 1.3 offers and one time. Provider, origin,
other addresses, internal systems, full certificate-chain algorithms and live
handshake signature algorithm remain unknown/unassessed. Business inputs are
operator-supplied or unknown. Recommendations require provider confirmation and
separate authorization for staging/deployment. No blanket quantum-safe verdict,
security score or compliance claim is made. Kernel buffering can receive the
read chunk that triggers an encrypted-byte limit; it is not forwarded into TLS.

Implementation is complete for independent checking; this builder does not grant
acceptance or readiness. The lead owns exact candidate, CI, draft PR and handoff.
