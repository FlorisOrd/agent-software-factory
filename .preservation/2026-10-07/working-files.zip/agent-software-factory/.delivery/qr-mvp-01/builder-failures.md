# Builder original failure and fix trail

Native builder: `/root/builder`. Loaded `AGENTS.md`, `.agents/skills/factory-delivery/SKILL.md`, `docs/ASF-MVP-01.md`, `.delivery/qr-mvp-01/requirements.md`.

## Real fixture smoke — first run

Tool chunk `b57822`, Node v24.19.0. Command imported `startFixtures()`, scanned each of the four fixed task-owned hostnames with bound authorization, and serialized their measured observations. Exit 1:

```text
TypeError: Do not know how to serialize a BigInt
    at JSON.stringify (<anonymous>)
    at file:///C:/Users/flori/OneDrive/Documenten/ChatGPT/agent-software-factory/[eval1]:1:250
Node.js v24.19.0
```

Cause: Node exposes the RSA public exponent as a BigInt in public-key metadata. Fix: preserve its exact value as a decimal string in JSON-safe observation metadata. No private key material was output. A regression assertion is included in the integration suite.

## First full suite

Original complete output: `builder-tests-first.txt`, tool chunk `c6f512`, exit 1, 13/15 passed.

- Export source-link assertion failed: observation anchors worked but source URLs remained plain text because an initial source edit did not match the intended text. Rewrote the small renderer with explicit source anchors; retained injection escaping.
- Host-header test expected 403 but received 200: Node's Fetch/Undici normalized the supplied Host header. Changed the test transport to raw `http.get` to actually send the hostile Host; the production host check is unchanged.

## Lockfile metadata refresh

Tool chunk `37c892`, exit 1: initial guessed bundled npm-cli.js path failed with `MODULE_NOT_FOUND`. Located the installed npm CLI under `C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js` and reran it using the bundled Node 24.19 binary. This was a local setup-path correction, not a product test failure.

The corrected lockfile refresh (chunk `6315a0`) exited 0, reporting `up to date`, with an EPERM warning for the unrelated default npm-cache log directory. The package lock's engine metadata was updated successfully. No npm log access was needed for the product.

## CI evidence-retention gap — 7 September 2026

Candidate `23433806a1d6c09ccb9c3eabf7431e1f5f6253cf` passed the functional CI jobs,
but product run `34094189381`, job `101653977206`, uploaded no artifact. The lead
read back an empty artifact API result. Original log is `ci-product.log`, lines
472–474, independently reread by the builder in tool chunk `6fdbb7`:

```text
2026-09-07T07:12:02.8452851Z ##[warning]No files were found with the provided path: products/quantum-readiness/.artifacts/browser-*.png
products/quantum-readiness/.artifacts/browser-check.json
products/quantum-readiness/.artifacts/controlled-reports.json. No artifacts will be uploaded.
```

Cause: `actions/upload-artifact` excludes hidden files/directories by default,
including the `.artifacts` parent directory. Its default warning behavior allowed
the job to finish successfully despite absent retained evidence. This was an
evidence-retention failure, not a failed scanner or browser check.

Fix: the dedicated product workflow explicitly enables hidden-file inclusion,
names only the three generated browser PNGs and two non-secret report JSON files,
and makes an empty upload selection an error. The prior wildcard is replaced by
exact filenames; no directory-wide or private-key upload is enabled. Confirmed
against the official action's [input documentation](https://github.com/actions/upload-artifact#inputs),
reviewed 7 September 2026. All five named files exist in the local controlled
evidence directory; original metadata readback is in tool chunk `6fdbb7`.

The source is frozen after this bounded workflow edit. Local diff/static checks
do not prove a remote upload; the lead must establish a new exact candidate,
obtain independent review, rerun CI and verify that candidate's artifact listing.
