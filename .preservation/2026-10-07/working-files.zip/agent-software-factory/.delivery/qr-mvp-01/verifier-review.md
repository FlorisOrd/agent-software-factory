# Independent verifier review — QR-MVP-01

Historical initial-candidate result: **CHANGES REQUESTED** on
`23433806a1d6c09ccb9c3eabf7431e1f5f6253cf`. The replacement candidate and verified
closure are recorded separately in `verifier-recheck.md`; that exact-candidate
recheck is the final verifier result.
The lead subsequently identified missing CI artifacts; independent inspection of
the original upload step confirmed it. See P2 finding below. The original local
review and initial completion have been preserved verbatim as
`verifier-review-initial.md` and `verifier-completion-initial.md`. Their earlier
no-blocking verdict is superseded by this finding and must not qualify a later SHA.
This is a native verifier's implementation review, not owner acceptance or
permission to merge/deploy. Local checks and the subsequently supplied original CI
logs were inspected. The lead owns the draft PR readback and final H evidence.

## Identity, instructions and exact revision

- Independent native verifier: `/root/verifier`, distinct from primary builder
  `/root/builder` and implementation helper `/root/builder/ui`.
- Parent lead: `/root`; available host session/task identifier supplied in the
  delivery record: `01a076a4-f394-7a70-8782-4d38585597b7`.
- Loaded root `AGENTS.md`, `.agents/skills/factory-delivery/SKILL.md`,
  `docs/ASF-MVP-01.md`, `.delivery/qr-mvp-01/requirements.md`, and
  `.delivery/qr-mvp-01/SESSION.md`. The Factory delivery skill was applied.
- Base: `223850dd8f909fcddef52dcc2bb5aff865f4472f`, tree
  `c2cca07b906792e7ea8bb2000aa754aec3a305b3`.
- Candidate: `23433806a1d6c09ccb9c3eabf7431e1f5f6253cf`, tree
  `c9652e6c0392def29d565201317a26bfe9046e87`, branch `codex/qr-mvp-01`.
- Independently read current checkout, clean working tree, changed-file list/stat,
  actual implementation files, configuration, tests, documentation, and root README
  diff. Inspected all 24 changed files. Existing Factory instructions and workflow
  were not changed. Final `git status --short` was empty; candidate source diff was
  empty and exact commit/tree unchanged (original tool chunk `c9b076`).
- No product/configuration source was edited by the verifier. Only ignored review
  evidence and a targeted-check source text file were added. Public destinations
  appearing in network instrumentation were never connected to.

## Independently executed evidence

Execution date: 7 September 2026. Runtime: bundled Node 24.19.0 / OpenSSL 3.5.7.
Browser: locally installed Edge selected through `QR_BROWSER_EXECUTABLE`; its
  measured version is preserved in `verifier-browser-check.json`.

| Check | Original result | Evidence |
| --- | --- | --- |
| `node --test --test-concurrency=1 test/*.test.mjs` in the product directory | 16/16 passed, exit 0 | `verifier-tests.txt`, tool chunk `cdcfa3` |
| `node scripts/browser-check.mjs` in the product directory | 12/12 passed, four real controlled TLS reports, exit 0 | `verifier-browser.txt`, chunks `2d8788` and `419d2d`; `verifier-browser-check.json` |
| `node --check scripts/check-workflow.mjs` and `node scripts/check-workflow.mjs` at repository root; syntax check each 13 product JS/MJS files | All passed, exit 0 | `verifier-static.txt`, chunk `38f8a6` |
| Additional independently written checks, source piped to `node --input-type=module` from repository root | 7/7 passed, exit 0 | `verifier-targeted-source.txt`, `verifier-targeted.txt`, chunk `8ce267` |

Original stdout is preserved in these files with candidate/tree/command headers.
The additional seven checks independently exercise 13 unsafe IPv6 forms through
the production scanner, incomplete AAAA results despite a public A answer,
IPv6-only numeric pinning of both probes with proxy environment set, the scanner's
own one-assessment concurrency limit, eviction of the oldest of 21 reports, the
real incomplete-body deadline (5012 ms, zero scanner calls), and exact round-trip
of all original report data from escaped HTML. Public DNS/connection behavior in
these cases is instrumented; HTTP requests use task-owned loopback servers only.

## Acceptance assessment

| ID | Local result and exact evidence |
| --- | --- |
| A | Met: actual task-owned classical TLS fixture negotiated X25519 with verified certificate/hostname. `classical-classical-tls13-v1` links that measured group to recorded-traffic confidentiality and proposed migration. Hybrid-only offer yielded bounded-negative, with incomplete coverage rather than unsupported-server inference. |
| B | Met: actual task-owned hybrid endpoint negotiated X25519MLKEM768, API returned `ephemeralKey.type=TLSGroup`, and certificate validation passed. Report separately retained RSA certificate key, exponent `65537`, and certificate signature metadata. This was a real handshake, not a parser mock or inference from runtime version. |
| C | Met locally: unsupported client group, unknown measured group/authentication type, handshake errors, untrusted certificate, wrong hostname, encrypted byte caps and timeout/abort cases remain incomplete. No successful result is generated by disabling certificate validation. |
| D | Met within private-pilot assumptions: permission before DNS/connect, strict hostname/443 grammar, IPv4/IPv6 deny rules, all-answer validation, canceled DNS deadline, two numeric pinned connections, no production fixture toggle, exact Host/Origin/token controls, concurrency/attempt/body/socket/report caps, and malicious output escaping were inspected and independently exercised. |
| E | Met: findings link actual observation IDs and versioned dated primary sources; key establishment, certificate authentication, symmetric inventory, and conventional/incomplete evidence remain distinct. Actions name the responsible party to confirm, dependencies, validation and rollback; unknown business/provider scope is retained. Six-step migration sequence requires separately authorized staging/deployment. |
| F | Met: browser happy/error paths and JSON/HTML downloads passed. JSON is identical to the report; the independently checked standalone HTML appendix exactly reconstructs the original report, including hostile certificate text. Observations remain available through evidence anchors. I visually inspected independently generated desktop form, hybrid report, and full mobile form screenshots. All are readable with explicit controlled-demo labels; mobile form had no horizontal overflow. |
| G | Met for inspected evidence: independent unit/integration/security/browser checks and existing Factory checks pass. CI configuration and the subsequently supplied original product/Factory CI logs were read; both show checks passing on the PR merge SHA and matching candidate tree recorded below. |
| H | Lead-owned: publish/read back one unmerged draft PR, attach original native/check evidence and tested CI SHA. This review does not claim that H is complete. |

Measured evidence and screenshots from the independent runs are preserved in
`verifier-controlled-reports.json`, `verifier-browser-check.json`,
`verifier-browser-demo.png`, `verifier-browser-report.png`, and
`verifier-browser-mobile.png`.

After the local review, the lead reported creation of
[draft PR 2](https://github.com/FlorisOrd/agent-software-factory/pull/2) and completion
of [product run 34094189381](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34094189381)
and [Factory run 34094189374](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34094189374).
I independently read the preserved original `ci-product.log` and `ci-factory.log`:
checkout logs identify merge `6de9ac78037ab8c911f9a9bc31aa8d3b1e4c1d53` as candidate
`23433806a1d6c09ccb9c3eabf7431e1f5f6253cf` merged into base
`223850dd8f909fcddef52dcc2bb5aff865f4472f`; both printed tree
`c9652e6c0392def29d565201317a26bfe9046e87`. Product CI reports Node 24.20.0,
16 passed tests and 12 passed browser checks/four real TLS reports; Factory checks
pass in both logs. The system CLI OpenSSL is 3.0.13 (fixture certificate generation),
distinct from Node's cryptographic runtime. I did not independently read GitHub's
live PR state; that remains the lead's remote readback responsibility. This is a
clear CI merge-SHA distinction, not a claim that CI checked the branch SHA directly.

## Code and evidence judgment

`src/targets.mjs` validates every A/AAAA result before returning one numeric
address. `src/tls-probe.mjs` connects to that number while preserving the requested
hostname as SNI and keeping `rejectUnauthorized:true` plus hostname verification.
The TLS code does not issue HTTP requests, re-resolve the hostname, use a proxy,
follow redirects, or fetch certificate-supplied URLs. The stream boundary counts
encrypted bytes before passing the triggering over-limit chunk into TLS. The
separate harness owns its endpoints and explicitly supplies its own trust anchor;
the production entry point never imports it. UI rendering uses text nodes, export
HTML escapes untrusted content, and export paths/filenames are process-owned IDs.

`src/rules.mjs` classifies measured group names, not TLS version, cipher suite or
certificate type. Only classical and standardized hybrid allowlists produce those
key-establishment findings. Other labels produce an evidence gap. Certificate key
authentication is reported independently; the live CertificateVerify signature and
full chain algorithm inventory are explicitly unobserved/unassessed. AES is not
declared broken, hybrid success is not a company-wide verdict, and increased RSA
key size is not suggested as a PQ migration solution. I found no blocking
misclassification or network-boundary bypass in the inspected candidate.

Primary sources independently checked on 7 September 2026:

- [RFC 10024](https://www.rfc-editor.org/rfc/rfc10024.html): finalized standards-track
  specification for the three recognized ECDHE/ML-KEM hybrid group names. Its
  X25519MLKEM768 registered identifier is 4588. The measured group is standardized,
  separate from the obsolete Kyber draft names.
- [NIST PQC FAQ](https://csrc.nist.gov/Projects/post-quantum-cryptography/faqs):
  symmetric-key guidance supports keeping AES interpretation distinct from
  quantum-vulnerable public-key migration.
- [NCCoE migration project](https://www.nccoe.nist.gov/applied-cryptography/migration-to-pqc):
  inventory and compatibility work support the proposed general migration sequence.
- [IANA IPv4 special registry](https://www.iana.org/assignments/iana-ipv4-special-registry)
  and [IPv6 special registry](https://www.iana.org/assignments/iana-ipv6-special-registry):
  compared the code's conservative exclusions with the listed non-public blocks.
  The implementation also deliberately rejects some special global exceptions.
- [Node TLS API](https://nodejs.org/api/tls.html#tlssocketgetephemeralkeyinfo):
  documents TLSGroup as the actual negotiated supported group. The accessible
  documentation was current Node 26; the versioned Node 24 URLs failed in the web
  tool. Node 24 runtime behavior was independently demonstrated by real handshakes,
  so it is not claimed from the current documentation alone.

## Failures, findings and limitations

### P2: CI succeeds without retaining the requested browser/report artifacts

- Discovered by the lead and independently confirmed by `/root/verifier` against
  the original product CI log. Relevant location:
  `.github/workflows/quantum-readiness.yml:47` through line 56, specifically
  `path` entries under hidden `.artifacts` and `if-no-files-found: warn` at line 56.
- Proof: `ci-product.log` upload step prints `include-hidden-files: false`, then
  `No files were found ... No artifacts will be uploaded.` The lead also observed
  an empty remote artifact list. Passing tests therefore did not deliver the
  configured CI screenshots and original structured observation records.
- Required correction: deliberately include the hidden directory with only the
  explicit non-secret report/screenshot paths, and fail when expected files are
  missing. Rerun CI on the replacement candidate and verify actual retained
  artifact contents and tested SHA. Do not include fixture private keys or broad
  directory globs. No customer/network/runtime changes are required by this finding.
- Delivery state: `CHANGES REQUESTED`; replacement candidate and independent
  recheck required. Original PR gate comment supplied by the lead:
  https://github.com/FlorisOrd/agent-software-factory/pull/2#issuecomment-5566652924

No local product check failure occurred. Builder's
original failure/fix record was read as context: the BigInt serialization, export
source links and hostile-Host transport assertions now pass independently. Their
original failures remain in `builder-failures.md` and linked original logs.

The verifier's first unquoted PowerShell `HEAD^{tree}` argument was misparsed;
quoted retry returned the correct tree. This was a read-only command issue, not a
product failure. Original diagnostic is preserved in `verifier-command-issues.txt`.
Versioned Node documentation lookup also returned a tool URL-safety error; current
official documentation plus actual installed-runtime checks were used as stated.

The tested live endpoints were task-owned IPv4 loopback fixtures only. Production
IPv4/IPv6 DNS/pinning behavior was tested using explicit instrumentation without
public connections. No customer or arbitrary third-party host was assessed; public
Internet path behavior, real providers, TLS 1.2, other groups/addresses/client
populations, origin/internal systems, full certificate-chain algorithms and live
handshake signatures remain outside this evidence. User declaration is not domain
ownership proof. The pilot assumes a trusted local machine/operator and requires a
different authorization/abuse design before public self-service. Kernel buffering
may receive the chunk that triggers the byte limit, but it is not forwarded into
TLS. General proposed actions are not verified customer configuration solutions.

This verifier neither accepts its own implementation nor grants final product
acceptance. Any new source candidate needs appropriate new exact-candidate checks
and independent review. Reverting the delivery PR under separate authorization
would remove the local product; no customer configuration was changed.
