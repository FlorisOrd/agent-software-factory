# Lead product walkthrough — 7 September 2026

Native lead `/root`, session `01a076a4-f394-7a70-8782-4d38585597b7`.
Local controlled demo: `http://127.0.0.1:8788/`, already launched by the builder.
The UI was operated through the supported in-app browser controls, then shown as
a deliverable. No public/customer target was assessed.

Observed actual behavior:

1. Entered `hybrid.qr.test` and submitted without checking permission. The browser
   showed the exact-target permission error and did not show a new assessment.
2. Confirmed the authorized task-owned hostname and submitted. The report showed
   real `X25519` and `X25519MLKEM768` observations, scoped successful coverage,
   separate RSA certificate / `sha256WithRSAEncryption` metadata, unknown business
   inputs and provider, dated rule links, proposed actions and limitations.
3. Clicked Download JSON. The browser emitted an actual download event.
4. Changed the hostname to `invalid.qr.test`. The permission checkbox reset.
   After confirming that controlled target, both observations showed
   `certificate-error`, failed certificate validation and incomplete coverage.
5. Returned to `hybrid.qr.test`, explicitly confirmed the task-owned target again,
   and left a fresh successful scoped report open for the owner.

Final displayed report: `4dd0fdde-a4d4-44e8-95a2-87016c0f4702`, timestamp
`2026-09-07T07:22:22.465Z`. Its actual HTML and JSON export links were retrieved to
`lead-hybrid-report.html` and `lead-hybrid-report.json` in this evidence directory.
The in-app screenshot was visually inspected after showing the report.

The source commit at final walkthrough was
`cbbfc11306db1f185147356022ea12d3b9aa47e3`, tree
`755dc0aaf89bca0af31a251f4149d1af75e1b3ac`. The running demo's product code is
unchanged from initial candidate `23433806a1d6c09ccb9c3eabf7431e1f5f6253cf`:
both product subtrees are `5f362ce549971c2fecee15d5f53e311a21fa4c31`.
The sole replacement-candidate change is CI artifact retention. The independent
verifier and fresh CI separately launched and tested the new exact checkout.

The original CI artifact upload gap is recorded in PR comment 5566652924 and
`ci-product.log`. The corrected run 34095003038 tested merge
`64b74afdb31338d0dcefbb35d353b9dbea3fdd9d`, with the final candidate tree above.
Its archive was downloaded from the GitHub connector to `ci-evidence.zip`.
Its SHA-256 matches the GitHub artifact digest:
`cacf2807e6a7f828645bb731ee76b4dc5c751d59f23ff9e10cf52d06fd0ec0f9`.
It contains exactly three browser PNGs and two non-secret JSON evidence files.
Both JSON files were inspected: 12 browser checks on Node 24.20.0 / OpenSSL 3.5.7,
and the expected measured classical/hybrid/certificate-failure/timeout outcomes.

This is lead demonstration evidence, separate from the native verifier's review
and the owner's final independent acceptance. The PR is left draft and unmerged.
