# Independent recheck — replacement QR-MVP-01 candidate

Final independent result: **NO BLOCKING FINDINGS on replacement candidate
`cbbfc11306db1f185147356022ea12d3b9aa47e3`**. Prior P2 is **FIXED AND VERIFIED**.
All independently rerun local checks pass, and the new CI upload and actual archive
contents have been independently inspected as recorded below. This result is tied
to the replacement SHA; it does not reuse the superseded initial verdict.

Native verifier: `/root/verifier`. Same loaded repository instructions and Factory
delivery skill as recorded in `verifier-review.md`; role remains distinct from
builder `/root/builder` and implementation helper `/root/builder/ui`. No product
source edits were performed by the verifier.

Base `223850dd8f909fcddef52dcc2bb5aff865f4472f`, base tree
`c2cca07b906792e7ea8bb2000aa754aec3a305b3`.
Initial candidate `23433806a1d6c09ccb9c3eabf7431e1f5f6253cf`, initial tree
`c9652e6c0392def29d565201317a26bfe9046e87`.
Replacement candidate **`cbbfc11306db1f185147356022ea12d3b9aa47e3`**, replacement tree
**`755dc0aaf89bca0af31a251f4149d1af75e1b3ac`**, branch `codex/qr-mvp-01`.

Independently confirmed clean checkout, exact SHA/tree and complete delta. Only
`.github/workflows/quantum-readiness.yml` changed (five additions, two deletions):
three exact PNG filenames replace a wildcard; `include-hidden-files: true` enables
the requested hidden directory; `if-no-files-found: error` makes absence of all
evidence fail. The two JSON filenames remain explicit. The whole product subtree
is identical on both revisions: `5f362ce549971c2fecee15d5f53e311a21fa4c31`.
Prior actual source/rule/boundary/UI inspection therefore applies to identical
source blobs; the following new executions independently check the replacement.

| Replacement check | Original result | Evidence |
| --- | --- | --- |
| Product `node --test --test-concurrency=1 test/*.test.mjs` | 16/16 passed, exit 0; real X25519 and X25519MLKEM768, wrong certificate and timeout results measured again | `verifier-recheck-tests.txt`, chunk `daf36a` |
| Product `node scripts/browser-check.mjs`, local Edge | 12/12 passed, four real TLS reports, exit 0 | `verifier-recheck-browser.txt`, chunk `c6423d` |
| Factory syntax/static checks plus syntax of all 13 product JS/MJS files | Passed, exit 0 | `verifier-recheck-static.txt`, chunk `caf063` |
| Same independently written seven extra checks, executed against replacement checkout | 7/7 passed, exit 0; 13 unsafe IPv6 cases reject before connection, numeric IPv6 pins, incomplete DNS errors, concurrency, 21-report eviction, actual 5021 ms body deadline, exact escaped HTML round-trip | `verifier-recheck-targeted.txt`, chunk `26e0e4` |
| Narrow artifact scope and local files | Five nonempty explicit filenames; JSON has no private-key markers; hidden inclusion and missing-file failure policy verified; checkout still clean/exact | `verifier-recheck-scope.txt`, chunk `34680e` |

The additional test source is unchanged `verifier-targeted-source.txt`; it carries
its original authoring-revision comment. The recheck execution log explicitly
identifies replacement candidate `cbbfc113...` and its actual source checkout.
Fresh original JSON and screenshots are copied as `verifier-recheck-browser-check.json`,
`verifier-recheck-controlled-reports.json`, and `verifier-recheck-browser-*.png`.

The scope helper's first comparison used Windows `Join-Path` backslashes against
YAML forward slashes and failed `Expected artifact path missing` (exit 1). This
verifier-only comparison bug was corrected to compare literal YAML paths; the
successful recheck is above. Its original stdout and explanation are preserved in
`verifier-recheck-scope-first.txt`. No product failure was hidden by that correction.

The prior P2 finding came from actual CI on initial candidate `23433806...`: the
lead discovered, and verifier confirmed, `include-hidden-files: false` followed by
`No artifacts will be uploaded.` Original product/Factory CI logs, initial review,
and superseded initial completion remain preserved. The replacement config fixes
the identified cause with a narrower non-secret path list. Fresh actual upload and
archive readback against the replacement CI SHA/tree have now passed.

## P2 closure: actual CI artifact independently verified

The verifier independently read original `ci-final-product.log` and
`ci-final-factory.log`, inspected the locally fetched Git merge object, hashed the
downloaded original `ci-evidence.zip`, enumerated every ZIP entry, parsed both JSON
files without extracting untrusted paths, and visually inspected the retained CI
hybrid-report screenshot. Original inspection/assertion stdout is preserved in
`verifier-recheck-ci.txt`, tool chunk `530421` (exit 0).

- [Product CI run 34095003038](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34095003038),
  job 101656538694: 16/16 tests; 12/12 browser checks with four real TLS reports;
  Factory checks passed; upload log explicitly reports five files and successful
  artifact finalization. `include-hidden-files: true` and `if-no-files-found: error`
  appear in the actual step inputs.
- [Factory CI run 34095003101](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34095003101),
  job 101656539123: existing Factory check passed.
- Both CI logs identify tested PR merge SHA
  `64b74afdb31338d0dcefbb35d353b9dbea3fdd9d`, tree
  `755dc0aaf89bca0af31a251f4149d1af75e1b3ac`. The fetched Git object independently
  confirms parents `223850dd8f909fcddef52dcc2bb5aff865f4472f` and
  `cbbfc11306db1f185147356022ea12d3b9aa47e3`; merge base is the original base.
  CI tested this merge SHA containing the candidate, with the candidate tree.
- [Artifact 10008252232](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34095003038/artifacts/10008252232)
  is 473571 bytes. Independently calculated SHA-256
  `cacf2807e6a7f828645bb731ee76b4dc5c751d59f23ff9e10cf52d06fd0ec0f9`
  exactly matches the original upload log digest. The lead separately checked the
  live API artifact metadata; this verifier's conclusion uses actual log/archive.
- Archive contains exactly `browser-demo.png` (163385 bytes), `browser-report.png`
  (143312), `browser-mobile.png` (180006), `browser-check.json` (65248), and
  `controlled-reports.json` (59679). Both parsed reports preserve all four labelled
  task-owned cases. Hybrid observation is `TLSGroup`/`X25519MLKEM768`, validation
  verified, certificate public-key type RSA. Classical offer/negative hybrid offer,
  failed certificate validation, and timeout remain separately recorded. No
  private-key markers occur in JSON; no key/secret file is in the archive.
- CI recorded Node 24.20.0, runtime OpenSSL 3.5.7 and Chromium 151.0.7922.34.
  The CI system OpenSSL 3.0.13 is only the fixture certificate generation CLI.
- The retained CI report screenshot is readable and clearly labels its controlled
  endpoint and limited coverage; extracted verified-name screenshots are preserved
  as `verifier-ci-browser-*.png`. Final local checkout was still clean and matched
  replacement commit/tree after the inspection.

The lead-discovered, verifier-confirmed missing-artifact finding is closed by the
builder's specific fix plus the new actual upload/archive evidence. No blocking
runtime, classification, network-boundary, UI or CI-evidence finding remains in
this candidate. Acceptance A-F and the inspected local/CI portions of G are met.
H's live draft PR state and complete published owner evidence remain lead-owned.

Limits remain unchanged: task-owned live TLS endpoints only, no public/customer
scan, no deployment or merge. Production IPv4/IPv6 connection boundaries are
instrumented without public connections. Only two TLS 1.3 profiles at one address
are assessed; authentication, internal systems and company-wide readiness cannot
be inferred from hybrid negotiation. The lead owns live PR state/CI metadata,
evidence publication and the owner handoff. Final acceptance remains with the owner.
