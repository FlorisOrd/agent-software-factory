# QR-MVP-01 owner handoff

**IMPLEMENTED — AWAITING INDEPENDENT VERIFICATION**

[Draft PR #2](https://github.com/FlorisOrd/agent-software-factory/pull/2) is ready
for final owner verification and remains unmerged. The native builder and a
different independent verifier completed their work; the verifier reports no
blocking findings on the exact final candidate.

The [controlled local demo](http://127.0.0.1:8788/) is running and open in the app.
It provides permission-bound TLS assessment, evidence-backed findings, a proposed
migration plan, and HTML/JSON exports. A fresh measured example is saved as
[HTML](lead-hybrid-report.html) and [JSON](lead-hybrid-report.json).

Actual task-owned endpoints demonstrated classical X25519 and standardized hybrid
X25519MLKEM768 negotiation. Reports correctly separated RSA certificate
authentication, rejected invalid certificates, and kept timeouts incomplete.
No customer or third-party system was scanned.

Checks passed: 16 product tests, 12 browser checks, seven additional independent
boundary/retention/export checks, existing Factory checks and 13 source syntax
checks. Fresh GitHub CI also passed. An initial CI upload gap was fixed and
independently rechecked; the actual archive now contains all five intended files.
Earlier export/test/setup failures and their fixes are preserved, not discarded.

- Base: `223850dd8f909fcddef52dcc2bb5aff865f4472f`.
- Final head: `cbbfc11306db1f185147356022ea12d3b9aa47e3`.
- Final tree: `755dc0aaf89bca0af31a251f4149d1af75e1b3ac`.
- CI-tested merge: `64b74afdb31338d0dcefbb35d353b9dbea3fdd9d`, with the same tree
  and the stated base/head as parents. This is a CI test merge, not a merged PR.
- Native builder: `/root/builder`; UI helper: `/root/builder/ui`; independent
  verifier: `/root/verifier`; lead: `/root`; standards researcher: `/root/standards`.
- Native host session: `01a076a4-f394-7a70-8782-4d38585597b7`.

[Full exact-revision evidence and original verifier results](https://github.com/FlorisOrd/agent-software-factory/pull/2#issuecomment-5566845309),
[original builder results and failure/fix trail](https://github.com/FlorisOrd/agent-software-factory/pull/2#issuecomment-5566699137),
[product CI](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34095003038),
[Factory CI](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34095003101),
and [retained demonstration archive](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34095003038/artifacts/10008252232)
are available for independent verification. The archive digest was verified as
`cacf2807e6a7f828645bb731ee76b4dc5c751d59f23ff9e10cf52d06fd0ec0f9`.

The scope remains a trusted-local-operator pilot: one address, two TLS 1.3 offers,
one time. Public IPv4/IPv6 boundaries were checked through instrumentation without
public connections. Company-wide readiness, provider/origin, internal systems,
other clients, full certificate-chain algorithms and live handshake signatures
remain unassessed. Hybrid negotiation does not establish PQ authentication or a
blanket quantum-safe verdict. Provider changes are proposed actions requiring
verification and separate authorization.

No business decision is needed to use the controlled demonstration. A future real
hostname needs explicit authorization. No exploitation, deployment, purchase or
merge occurred. A separately authorized rollback can revert/remove the two
delivery commits; no customer system configuration needs reversing.
