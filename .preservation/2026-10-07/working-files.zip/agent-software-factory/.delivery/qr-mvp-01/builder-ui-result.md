# QR-MVP-01 interface implementation helper

- Native task: `/root/builder/ui`; parent builder: `/root/builder`.
- Role: implementation helper, not independent verifier.
- Loaded instructions: root `AGENTS.md`, `.agents/skills/factory-delivery/SKILL.md`, `docs/ASF-MVP-01.md`, and `.delivery/qr-mvp-01/requirements.md`.
- Scope: `products/quantum-readiness/public/index.html`, `app.js`, `style.css`; `products/quantum-readiness/scripts/browser-check.mjs`; new `.github/workflows/quantum-readiness.yml`.
- Git operations: none. Implementation checks below concern the shared working candidate before the lead's exact-commit review.

The UI includes exact-host permission binding, optional business context with unknown defaults, a clearly labelled controlled demo selector, scoped findings, source links, links to original observations, migration actions, and HTML/JSON downloads. Untrusted strings use DOM text content. Assessment errors and incomplete coverage remain explicit. Desktop and narrow-screen screenshots were inspected; a missing space around a responsive line break was corrected.

Executed the browser check with the bundled Node runtime and local Microsoft Edge. Both original runs passed with exit code 0: `builder-ui-browser-initial.txt` and `builder-ui-browser-recheck.txt`. Each run completed 12 checks and collected four actual local TLS reports: classical, hybrid, certificate-invalid, and timeout. The hostile-field rendering case alone uses a labelled mocked API response. No external target was assessed.

The browser evidence preserves full reports, measured negotiated groups, certificate outcomes, optional input source labels, exact JSON export equality, HTML export content, and browser/runtime versions in `products/quantum-readiness/.artifacts/browser-check.json`. Screenshots are `browser-demo.png`, `browser-report.png`, and `browser-mobile.png` in the same directory. These generated files are ignored locally; CI uploads only the three screenshot names via a narrow browser PNG glob and the JSON evidence, excluding fixture credentials.

These checks are implementation evidence. Independent verification against the final candidate and a successful CI run remain the lead's delivery gates.
