import { writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { startDemo } from '../../products/quantum-readiness/scripts/demo.mjs';

const app = await startDemo({ port: 0 });
const revision = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8', windowsHide: true }).trim();
await writeFile(new URL('./lead-demo.json', import.meta.url), JSON.stringify({url: app.url, pid: process.pid, revision, startedAt: new Date().toISOString()}, null, 2));
console.log(`Task-owned controlled demo: ${app.url}; revision ${revision}`);
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await app.close(); process.exit(0); });
