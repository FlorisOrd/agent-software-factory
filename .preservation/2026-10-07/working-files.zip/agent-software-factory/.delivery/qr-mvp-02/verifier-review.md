# QR-MVP-02 independent verification

Result: **NO BLOCKING FINDINGS** on candidate `e8fab07547c6ccaaae9b83be350332caf47e1a6b`.
This is an exact-candidate code and controlled-behavior review. Remote draft/CI
readback and the final owner handoff remain the lead's delivery responsibilities.
It is not permission to merge, deploy, or assess a customer/third-party target.

## Identity, instructions, revision and scope

- Native verifier task: `/root/verifier`, distinct from `/root/builder` and
  `/root/builder/coverage_ui`.
- Verifier `CODEX_THREAD_ID`, read directly from the environment:
  `01a07b1e-782a-7a41-8399-a2dade3b5474`.
- Shared `CODEX_SESSION_ID`, read directly from the environment:
  `01a07b0e-80a3-7d33-9f98-d9d998b94cc0`.
- Loaded actual files: root `AGENTS.md`,
  `.agents/skills/factory-delivery/SKILL.md`, `docs/ASF-MVP-01.md`, and the
  exact owner request `.delivery/qr-mvp-02/requirements.md`. Also inspected
  `.delivery/qr-mvp-02/SESSION.md` and its scoped ignore file.
- Base: `dbdee018e5a128b08b413f4d1a71128256a58aec`.
- Base tree: `755dc0aaf89bca0af31a251f4149d1af75e1b3ac`.
- Candidate: `e8fab07547c6ccaaae9b83be350332caf47e1a6b`.
- Candidate tree: `3bef42af1bde25afb715ff69efbe06117b599ea5`.
- Branch: `codex/qr-mvp-02`; tracked worktree clean before and after review.
- Actual base-to-candidate diff contains 22 files: 19 product/CI files and three
  delivery documentation/ignore files. Factory instruction/skill/helper workflow
  files are unchanged. No implementation, dependency, test, or tracked evidence
  file was edited by this verifier. Extra scripts and evidence are ignored under
  `.delivery/qr-mvp-02/verifier-*`.
- Runtime: bundled Node `24.19.0`, OpenSSL `3.5.7`, browser suite using installed
  Edge `152.0.4191.66` via `QR_BROWSER_EXECUTABLE`.
- Capability: actual native independent execution, repository reads, local fixture
  listening, browser automation and ignored evidence writes succeeded. No
  additional access or permission bypass was needed. Native agents share a
  workspace; their identities do not establish an isolated security boundary.
- Additional bounded read-only logic review by native task
  `/root/verifier/logic_check` found no blocker after inspecting the same exact
  candidate's network, aggregation and rendering paths. It performed no tests,
  scans or file changes. Its original result is `verifier-logic-review.md`.

## Independent execution and original evidence

All commands used
`C:/Users/flori/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe`.

| Check | Actual result | Original evidence / tool output |
| --- | --- | --- |
| `node --test --test-concurrency=1 products/quantum-readiness/test/*.test.mjs` | 23 passed, 0 failed | `verifier-product-tests.log`; chunk `0cc507` |
| `node products/quantum-readiness/scripts/browser-check.mjs` | 16 passed, 7 real fixture reports, no browser errors | `verifier-browser.log`; chunks `ed9071`, `1fd18f` |
| `node --test --test-concurrency=1 .delivery/qr-mvp-02/verifier-extra.test.mjs` | 6 passed, 0 failed | `verifier-extra-tests.log`; chunk `18e78d` |
| `node scripts/check-workflow.mjs` | PASS; static discovery structure only | `verifier-factory.log`; chunk `d64182` |
| `node --check` for 15 product JavaScript files and Factory helper; `git diff --check base head` | All passed | `verifier-revision-syntax.json`; chunk `89bbdb` |

Generated evidence was immediately copied into `verifier-artifacts/` after the
independent product/browser runs, preserving verifier results separately from
builder artifacts. It includes `controlled-reports.json`,
`controlled-multi-address-reports.json`, `browser-check.json`, seven browser
screenshots, and verifier-only `extra-controlled-evidence.json`. The extra test
source and original logs are retained. The artifact manifest contains SHA-256
hashes of these original verification files.

No product failure occurred in the independent reruns. An initial read-only
unquoted PowerShell `git rev-parse HEAD^{tree}` invocation was parsed incorrectly;
the quoted expression succeeded and confirmed both tree IDs. No product change
was made in response. Builder's prior failed single-address expectation and
corrected passing output remain separate builder evidence.

## Controlled acceptance A-J

| Criterion | Independent evidence and conclusion |
| --- | --- |
| A | Reran real task-owned mixed/consistent/capped listeners. Multi-address artifact records 14 accepted TCP connections: two profiles each to `127.0.0.1` and `::1` for mixed and consistent, plus `127.0.0.2` for sampled. Each hostname's listeners share one port. Each observation retains selected and actually connected numeric address, profile, SNI and timestamp. |
| B | Mixed IPv4 endpoint negotiates classical `prime256v1` and rejects the bounded hybrid offer; IPv6 negotiates classical `X25519` and hybrid `X25519MLKEM768`. Four cross-address findings preserve exact observation references, including hybrid/classical-group differences and evidence/certificate-validation gaps. They explicitly disclaim proof of absent PQ support. |
| C | Consistent two-address and three-selected-address cases negotiate matching profile outcomes and produce zero cross-address findings. Extra checks cover five uniformly incomplete outcomes and equivalent P-256 spellings without manufactured differences. |
| D | Production-path instrumentation rejects unsafe, malformed, family-mismatched, over-cap and incomplete DNS results before any connection. Extra checks insert unsafe/malformed answers into all 16 result positions (145 cases including mixed-family unsafe DNS); socket call count remains zero. |
| E | Numeric IPv4/IPv6 sort, interleave, three-address cap and canonical deduplication were checked. Extra test covers all 720 permutations of six answers including equivalent IPv6 spelling, preserving exact raw-answer provenance and invariant selected/unselected lists. The real four-address sample leaves `127.0.0.3` uncontacted. |
| F | Production instrumentation proves one A and one AAAA lookup and six numeric socket options, with rebinding answers available only to a prohibited second lookup. Maximum local socket concurrency is one. Extra mismatch instrumentation gives a different actual remote address and confirms `QR_ADDRESS_MISMATCH` before any TLS creation. Real fixture probes retain requested hostname for SNI/checkServerIdentity and normal rejection of invalid trust/hostname. |
| G | Existing classical/hybrid, unknown group/authentication, unsupported client, certificate trust/hostname, timeout/error, encrypted-byte, export, permission and operator business-context regression tests pass. Complete original reports including every observation and sampling metadata survive JSON/HTML downloads. No numerical readiness score is introduced. |
| H | All 23 current product tests, including retained QR-MVP-01 regressions, pass; Factory static check and syntax pass. |
| I | Browser suite passes 16 checks and produces seven real reports. Tests verify coverage counts, exact addresses, per-address cards, cross-address findings, unique evidence anchors, complete downloaded JSON/HTML, malicious text safety and 390-pixel layout. Independently viewed mixed coverage/evidence and capped mobile screenshots: readable, no clipping. |
| J | This distinct native verifier inspected the exact diff/source and reran the checks above, plus six additional adversarial tests at the unchanged candidate. Builder explanations were not used as execution proof. |

## Network-boundary and interpretation review

`resolvePublicTarget` completes bounded A/AAAA resolution, rejects invalid policy
answers before canonicalization/selection, limits raw answer count to 16, and
preserves raw and canonical inventories. Production address policy was preserved;
the isolated harness never enters production's import graph. Public-looking IPs
used in instrumentation never reached the network.

The scanner selects at most three addresses and offers two existing TLS 1.3
profiles per address. Numeric `net.connect` destinations are checked against the
raw connected address before TLS construction. TLS retains `servername`, normal
`checkServerIdentity` and `rejectUnauthorized: true`; production supplies no
fixture CA. Connections use the existing restricted offers, no proxy/redirect,
no certificate URL fetching and no application request.

The prior raw socket closes before the next probe resolves to its caller. Shared
encrypted-byte counters prevent later probes after exhaustion. Independent
outgoing-budget testing measured the triggering 1,435-byte ClientHello attempt,
forwarded none of it beyond a 64-byte test budget, and prevented the next socket
attempt. Existing real inbound budget testing also passes. The 30-second global
abort leaves remaining selected observations explicitly skipped, closes active
work, and releases scanner state; extra checks prove a concurrent request is
rejected and a following assessment can run with one local socket active at most.

Per-address summaries distinguish attempted from successful profiles. Sampling
metadata distinguishes selected/unselected from assessed/unassessed. Incomplete
observations remain explicit. Cross-address comparison uses like-for-like client
profiles and normalizes equivalent runtime P-256/P-384 group labels; actual
differences remain scoped observations, not claims about unmeasured capability.
Authentication, key establishment, symmetric crypto, business context and
migration planning remain separate. Hybrid success does not imply PQ
authentication, other-address/origin/internal readiness or company-wide safety.

Browser text rendering and escaped HTML preserve safe evidence display and
complete raw appendices. Existing loopback Host/Origin/CSRF, body/rate/concurrency,
report expiry and bounded retention controls are unchanged and independently
tested. CI changes only add explicit non-secret controlled artifact filenames.

## Limits and delivery handoff

- Real endpoints were synthetic task-owned IPv4/IPv6 loopback fixtures with
  ephemeral certificates; these do not claim public DNS deployment coverage.
  Production DNS and numeric pinning policy were verified with instrumentation
  that performed no public/customer/third-party connection.
- Sampling is deterministic, bounded and point-in-time. It cannot establish
  coverage of unselected addresses, other DNS answers, edges or client populations.
- Byte limits are documented processing stops; counters may include the chunk
  triggering a stop and kernel buffers can receive it. This is not a hard
  wire-delivery byte limit.
- Local Edge was used. Linux/Chromium execution and exact remote tested SHA/CI
  outcome must be supplied by the lead's CI readback.
- Static Factory checks verify installed structure. This product change does not
  modify Factory discovery/coordination and does not claim a new workflow bootstrap
  experiment or technical enforcement gate.
- No deployment, customer scan, remote configuration change, push or merge was
  performed by the verifier. If separately authorized later, reverting the
  delivery PR restores QR-MVP-01's single-address behavior.
