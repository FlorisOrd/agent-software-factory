## Final delivery evidence — READY FOR OWNER REVIEW

QR-MVP-02 is implemented and independently checked. **PR #3 remains draft, open and unmerged.** Owner product acceptance, merge, deployment and real-world/customer assessment remain separate decisions.

### Exact candidate and CI

| Item | Verified value |
| --- | --- |
| Base / merge base | `dbdee018e5a128b08b413f4d1a71128256a58aec` |
| Base tree | `755dc0aaf89bca0af31a251f4149d1af75e1b3ac` |
| Candidate / remote PR head | `e8fab07547c6ccaaae9b83be350332caf47e1a6b` |
| Candidate tree | `3bef42af1bde25afb715ff69efbe06117b599ea5` |
| GitHub tested merge | `b6a11df86e87b74c84090dcdd6b23df9bb0a04da` |
| Tested merge tree | `3bef42af1bde25afb715ff69efbe06117b599ea5` |

The tested merge has exactly the stated base and head as parents. Original logs from both workflows name this merge SHA and matching tree; it is a CI test merge, not an actual PR merge. Final remote readback confirmed the exact head, draft state and `merged: false`; the local tracked worktree is clean.

- [Product CI — success, run 34104244324](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34104244324): 23 product tests, 16 browser checks with seven real reports, and preserved Factory check.
- [Factory CI — success, run 34104244345](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34104244345): syntax and static installation/discovery check.
- CI runtime: Node 24.20.0 / OpenSSL 3.5.7; browser evidence records Chromium 151.0.7922.34. Independent local runtime: Node 24.19.0 / OpenSSL 3.5.7 / Edge 152.0.4191.66.
- [Verified ten-file CI evidence archive](https://github.com/FlorisOrd/agent-software-factory/actions/runs/34104244324/artifacts/10011730716): seven PNGs and three JSON files, including complete single/multi-address reports, raw server connection records and browser evidence. Downloaded ZIP SHA-256 matches GitHub's digest: `10bf2b982b618cc99793855ca89c00dfa4a776379d0a1f8c9561906a5f96923b`. The archive was opened and its contents checked: 16 passed browser checks, seven reports and 14 real recorded multi-address contacts.

### Controlled demonstrations and independent evidence

| Controlled case | Actual result |
| --- | --- |
| `mixed.qr.test` | Two real addresses at one shared port: IPv4 `127.0.0.1` measured classical `prime256v1` and a bounded-negative hybrid offer; IPv6 `::1` measured `X25519` and `X25519MLKEM768`. Reports preserve all four connected-address observations and explicitly scoped cross-address differences. |
| `consistent.qr.test` | Both real IPv4/IPv6 addresses measured matching profile outcomes; no inconsistency manufactured. |
| `sampled.qr.test` | Four task-owned fixture addresses, three assessed: `127.0.0.1`, `::1`, `127.0.0.2`. The fourth, `127.0.0.3`, was unselected and uncontacted. Six original observations retained, no inconsistency manufactured. |
| Production boundary instrumentation | All DNS answers validated before sampling, unsafe/malformed results fail with zero connections, one A/AAAA resolution, six numeric pinned attempts, no public network contact, maximum one local socket active. |
| Deadline/byte boundaries | Global expiry closes active work and prevents later attempts; remaining profiles retain explicit skipped evidence. Shared byte exhaustion prevents another connection. Normal certificate/SNI/hostname checks remain enabled. |

The separate native verifier independently reran all product/browser/Factory checks and six additional adversarial checks, including **720 DNS permutations**, **145 invalid-answer cases with zero connections**, connected-address mismatch before TLS, deadline state recovery and real IPv4/IPv6 hostname/trust instrumentation. **No blocking findings.**

- [Original builder identity, completion, failure and fixed checks](https://github.com/FlorisOrd/agent-software-factory/pull/3#issuecomment-5568324755).
- [Exact-candidate independent native review, original logs, extra test source, hashes and A-J matrix](https://github.com/FlorisOrd/agent-software-factory/pull/3#pullrequestreview-5130212078).
- Lead `/root`, host session `01a07b0e-80a3-7d33-9f98-d9d998b94cc0`; builder `/root/builder`, actual thread `01a07b10-3527-7661-a794-4c868d1b2e42`; verifier `/root/verifier`, actual thread `01a07b1e-782a-7a41-8399-a2dade3b5474`. Native helpers: builder UI `/root/builder/coverage_ui`, read-only acceptance adviser `/root/acceptance_audit`, supplemental independent logic reviewer `/root/verifier/logic_check`. Distinct execution IDs do not imply isolated permissions/hardware.
- Loaded repository instructions, Factory skill and exact owner request are recorded in [SESSION.md](https://github.com/FlorisOrd/agent-software-factory/blob/e8fab07547c6ccaaae9b83be350332caf47e1a6b/.delivery/qr-mvp-02/SESSION.md).

The lead separately launched this exact committed source and operated its in-app browser. Missing permission for `mixed.qr.test` displayed the target-bound error; after authorization the UI showed both measured addresses and the cautious mixed-posture findings. Clicking Download JSON produced an actual browser download event. The four-address journey visibly showed **4 validated fixture addresses / 3 assessed / 1 unassessed**, exact address lists, cap reason and no inconsistency. Its HTML/JSON reports were retrieved and retained locally. The current controlled demo is available on the owner's machine at `http://127.0.0.1:60011/#address-coverage`. This is a task-owned loopback demo, not deployment or a customer assessment.

### Failures, fixes and remaining limits

The original stale two-probe test expectation failed when multi-address behavior correctly produced four probes. The single-address regression was preserved with one DNS answer and a separate six-probe test added; all final checks passed. Initial PATH Node16/helper and Git/network sandbox setup failures were resolved using the existing bundled Node24 runtime, authorized Git escalation and GitHub connector. A sandboxed archive download was denied; authorized escalation retrieved the same archive and its digest matched. These setup/test failures were retained; no validation policy was weakened and no independent product test failure remains.

Sampling remains deterministic, bounded and point-in-time. Fixture address inventories are explicitly labelled and do not claim public DNS validation; public policy uses instrumentation with no public connections. Byte limits are processing stops with a documented triggering-chunk/kernel-buffer qualification. One successful hybrid connection does not prove absent capability elsewhere, PQ authentication, origin/internal readiness or whole-company safety. No score, broader scanner, public service, automatic changes or customer scan was introduced.

Rollback, if later separately authorized after merge, is to revert `e8fab07547c6ccaaae9b83be350332caf47e1a6b`, restoring the merged QR-MVP-01 single-address behavior. No remote customer configuration or deployment needs rollback.

<details><summary>Exact 22 changed files</summary>

```text
.delivery/qr-mvp-02/.gitignore
.delivery/qr-mvp-02/SESSION.md
.delivery/qr-mvp-02/requirements.md
.github/workflows/quantum-readiness.yml
products/quantum-readiness/README.md
products/quantum-readiness/package-lock.json
products/quantum-readiness/package.json
products/quantum-readiness/public/app.js
products/quantum-readiness/public/index.html
products/quantum-readiness/public/style.css
products/quantum-readiness/scripts/browser-check.mjs
products/quantum-readiness/scripts/demo.mjs
products/quantum-readiness/src/assessment.mjs
products/quantum-readiness/src/limits.mjs
products/quantum-readiness/src/report.mjs
products/quantum-readiness/src/rules.mjs
products/quantum-readiness/src/targets.mjs
products/quantum-readiness/src/tls-probe.mjs
products/quantum-readiness/test/harness.mjs
products/quantum-readiness/test/integration.test.mjs
products/quantum-readiness/test/multi-address.test.mjs
products/quantum-readiness/test/security.test.mjs
```
</details>
