// Independent verifier checks. Mocked public-looking addresses never reach the network.
import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import tls from 'node:tls';
import { Resolver } from 'node:dns/promises';
import { writeFile } from 'node:fs/promises';
import { resolvePublicTarget, sampleValidatedAddresses } from '../../products/quantum-readiness/src/targets.mjs';
import { createPublicScanner, buildReport } from '../../products/quantum-readiness/src/assessment.mjs';
import { probeTls, PROFILES, LIMITS } from '../../products/quantum-readiness/src/tls-probe.mjs';
import { interpretAcrossAddresses } from '../../products/quantum-readiness/src/rules.mjs';
import { startFixtures } from '../../products/quantum-readiness/test/harness.mjs';

const input=hostname=>({hostname,authorized:true,authorizedHostname:hostname});
const answer=(address,family=net.isIP(address))=>({address,family});
function* permutations(items) {
  if(items.length<2){yield items;return;}
  for(let i=0;i<items.length;i++)for(const tail of permutations(items.filter((_,j)=>i!==j)))yield [items[i],...tail];
}

test('independent: all 720 orderings preserve numeric family sampling and canonical duplicate provenance',async()=>{
  const raw=['11.0.0.10','11.0.0.2','11.0.0.100','2606::10','2606::2','2606:0:0:0:0:0:0:2'].map(x=>answer(x));
  const expected={selectedAddresses:['11.0.0.2','2606::2','11.0.0.10'].map(x=>answer(x)),unselectedAddresses:['2606::10','11.0.0.100'].map(x=>answer(x))};
  let tested=0;
  for(const ordering of permutations(raw)) {
    const result=await resolvePublicTarget('permutations.qr.test',{resolver:async()=>ordering});
    assert.deepEqual(result.sampling.selectedAddresses,expected.selectedAddresses);
    assert.deepEqual(result.sampling.unselectedAddresses,expected.unselectedAddresses);
    assert.deepEqual(result.validatedDnsAnswers,ordering);
    assert.equal(result.sampling.totalValidatedAddresses,5);
    assert.equal(result.sampling.duplicateAnswers,1);tested++;
  }
  assert.equal(tested,720);
  console.log(JSON.stringify({independent:'all DNS permutations',tested,...expected}));
});

test('independent: unsafe DNS answer in all 16 positions fails before any connection and scanner recovers',async t=>{
  let v4=[],v6=[],connectCalls=0;
  t.mock.method(Resolver.prototype,'resolve4',async()=>v4);
  t.mock.method(Resolver.prototype,'resolve6',async()=>v6);
  t.mock.method(net,'connect',()=>{connectCalls++;throw new Error('No public contact authorized');});
  const scanner=createPublicScanner();let cases=0;
  for(const unsafe of ['127.0.0.1','169.254.169.254','198.18.0.1','224.0.0.1','::1','2606::1%eth0',null,{},'11.00.0.2']) {
    for(let position=0;position<16;position++) {
      v4=Array(16).fill('11.0.0.2');v4[position]=unsafe;
      await assert.rejects(scanner(input('all-answers.qr.test')));cases++;
      assert.equal(connectCalls,0);
    }
  }
  v4=['11.0.0.1','11.0.0.2','11.0.0.3'];v6=['2606::2','2001:db8::2'];
  await assert.rejects(scanner(input('all-answers.qr.test')));assert.equal(connectCalls,0);
  console.log(JSON.stringify({independent:'invalid answers before every possible selected/unselected position',cases:cases+1,connectCalls}));
});

test('independent: wrong connected address is rejected before TLS creation, while normal numeric options are retained',async t=>{
  let tlsCalls=0;const options=[];
  t.mock.method(tls,'connect',()=>{tlsCalls++;throw new Error('TLS must not start on a mismatched address');});
  t.mock.method(net,'connect',opts=>{
    options.push(opts);const socket=new net.Socket();
    Object.defineProperty(socket,'remoteAddress',{value:'127.0.0.99'});
    process.nextTick(()=>socket.emit('connect'));return socket;
  });
  const report=await probeTls({hostname:'mismatch.qr.test',address:'11.0.0.2',family:4,port:443},PROFILES[0]);
  assert.equal(report.status,'error');assert.equal(report.error.code,'QR_ADDRESS_MISMATCH');
  assert.equal(report.resolvedAddress,'11.0.0.2');assert.equal(report.connectedAddress,'127.0.0.99');
  assert.equal(tlsCalls,0);assert.deepEqual(options,[{host:'11.0.0.2',port:443,family:4}]);
  console.log(JSON.stringify({independent:'connected address mismatch fails before TLS',status:report.status,error:report.error,tlsCalls,options}));
});

test('independent: global deadline closes socket, prevents pending connections, rejects concurrent scan and releases scanner state',async t=>{
  let dns4=0,dns6=0,connects=0,active=0,maxActive=0;let triggerDeadline=true;
  t.mock.timers.enable({apis:['setTimeout']});
  t.mock.method(Resolver.prototype,'resolve4',async()=>{dns4++;return ['11.0.0.3','11.0.0.2'];});
  t.mock.method(Resolver.prototype,'resolve6',async()=>{dns6++;return ['2606::2'];});
  let openedResolve;const opened=new Promise(resolve=>openedResolve=resolve);
  t.mock.method(net,'connect',()=>{
    connects++;active++;maxActive=Math.max(maxActive,active);
    const socket=new net.Socket();socket.on('close',()=>active--);
    if(triggerDeadline){openedResolve();}
    else process.nextTick(()=>socket.emit('error',Object.assign(new Error('Controlled refusal; no network call'),{code:'ECONNREFUSED'})));
    return socket;
  });
  const scanner=createPublicScanner();const pending=scanner(input('release.qr.test'));
  await opened;
  await assert.rejects(scanner(input('release.qr.test')),/already running/);
  assert.equal(dns4,1);assert.equal(dns6,1);
  t.mock.timers.tick(LIMITS.assessmentMs+1);
  const timed=await pending;
  assert.equal(active,0);assert.equal(connects,1);assert.equal(timed.observations.length,6);
  assert.ok(timed.observations.every(x=>x.status==='timeout'));
  assert.ok(timed.observations.slice(1).every(x=>!x.connectionAttempted));
  triggerDeadline=false;
  const recovered=await scanner(input('release.qr.test'));
  assert.equal(dns4,2);assert.equal(dns6,2);assert.equal(connects,7);assert.equal(active,0);assert.equal(maxActive,1);
  assert.ok(recovered.observations.every(x=>x.status==='error' && x.connectionAttempted));
  console.log(JSON.stringify({independent:'deadline and scanner-state release',dns4,dns6,connects,maxActive,timedAssessed:timed.scope.sampling.assessedCount,recoveredAssessed:recovered.scope.sampling.assessedCount}));
});

test('independent: fully incomplete equal evidence and equivalent group spellings do not manufacture differences',()=>{
  const selected=['11.0.0.2','2606::2'].map(x=>answer(x));
  const rows=status=>selected.flatMap(address=>PROFILES.map(profile=>({id:`${profile.id}@${address.address}`,profile,status,resolvedAddress:address.address,connectionAttempted:true,certificateValidation:{status:'not-completed'},certificate:null,keyExchangeGroup:null})));
  for(const status of ['error','timeout','bounded-negative','tool-unsupported','limit-exceeded']) {
    const observations=rows(status);
    assert.deepEqual(interpretAcrossAddresses(observations,selected),[]);
    const report=buildReport({hostname:'incomplete.qr.test',sensitivity:'unknown',confidentiality:'unknown'},{hostname:'incomplete.qr.test',port:443,...selected[0],resolvedAddresses:selected,sampling:sampleValidatedAddresses(selected)},observations,false);
    assert.match(report.coverage,/Incomplete/);assert.equal(report.crossAddressFindings.length,0);
  }
  const equivalent=rows('negotiated').map((obs,i)=>({...obs,certificateValidation:{status:'verified'},certificate:{signatureAlgorithm:'sha256WithRSAEncryption',publicKeyType:'rsa'},keyExchangeGroup:i%2?'X25519MLKEM768':i===0?'prime256v1':'secp256r1'}));
  assert.deepEqual(interpretAcrossAddresses(equivalent,selected),[]);
});

test('independent: actual controlled connections retain hostname verification and shared outgoing stop blocks next connection',async t=>{
  const fixtures=await startFixtures();t.after(()=>fixtures.close());
  const originalConnect=tls.connect;const tlsOptions=[];
  t.mock.method(tls,'connect',options=>{tlsOptions.push(options);return originalConnect.call(tls,options);});
  const endpoint=fixtures.endpoints['consistent.qr.test'];
  const report=await fixtures.scan(input('consistent.qr.test'));
  assert.equal(report.observations.length,4);
  assert.ok(tlsOptions.every(o=>o.servername==='consistent.qr.test' && o.rejectUnauthorized===true && o.checkServerIdentity===tls.checkServerIdentity && o.ca===fixtures.ca && o.socket));
  assert.ok(report.observations.every(o=>o.certificateValidation.hostnameChecked==='consistent.qr.test' && o.certificateValidation.status==='verified'));
  assert.equal(report.crossAddressFindings.length,0);
  const shared={received:0,sent:0};const limits={...LIMITS,assessmentOutgoingBytes:64};
  const before=fixtures.counts.accepted;
  const stopped=await probeTls(endpoint,PROFILES[1],{ca:fixtures.ca,limits,aggregateBytes:shared});
  assert.equal(stopped.status,'limit-exceeded');assert.ok(shared.sent>64);assert.equal(stopped.bytes.received,0);
  const skipped=await probeTls(endpoint,PROFILES[0],{ca:fixtures.ca,limits,aggregateBytes:shared});
  assert.equal(skipped.status,'limit-exceeded');assert.equal(skipped.connectionAttempted,false);
  assert.equal(fixtures.counts.accepted-before,1);
  await writeFile(new URL('./verifier-artifacts/extra-controlled-evidence.json',import.meta.url),JSON.stringify({report,outgoingStopped:stopped,outgoingSkipped:skipped,shared,serverConnections:fixtures.counts.connections},null,2));
  console.log(JSON.stringify({independent:'real IPv4/IPv6 hostname and trust checks; global outgoing-byte stop',connected:report.observations.map(o=>o.connectedAddress),tlsCalls:tlsOptions.length,shared,stopped:stopped.status,skipped:skipped.status,subsequentConnectionAttempted:skipped.connectionAttempted}));
});
