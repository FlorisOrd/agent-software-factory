Implementation frozen for the lead to commit and independently verify. No commits, pushes, scans of third parties, or deployments performed.

Native identities: builder `/root/builder`; delegated UI helper `/root/builder/coverage_ui`. Both loaded `AGENTS.md`, Factory delivery skill, `docs/ASF-MVP-01.md`, and the exact owner attachment.

Delivered:

- Validate every DNS answer before deduplication or sampling; retain original answers and canonical unique destinations.
- Deterministic IPv4/IPv6 sample capped at three addresses, six sequential profiles, 30-second assessment deadline, shared encrypted-byte budgets.
- Numeric pinning, SNI and certificate hostname verification; skipped probes after exhausted deadlines/budgets open no connections.
- Unique observation IDs, per-address evidence, cross-address interpretation, coverage UI and complete HTML/JSON exports.
- Real task-owned mixed, consistent and capped IPv4/IPv6 fixtures.
- Product README/version and dedicated product CI evidence updates. Factory workflow unchanged.

Checks:

- **23/23 product tests:** `products/quantum-readiness/.artifacts/builder-final-tests.log`; original result `0fb5b8`.
- **16/16 browser checks, seven real fixture reports:** `.artifacts/builder-browser-first.log`, `.artifacts/browser-check.json`; original completion `c45191`.
- **Factory syntax/check:** `.delivery/qr-mvp-02/builder-factory.log`; original result `0b9594`.
- **Controlled evidence:** `.artifacts/controlled-multi-address-reports.json` preserves 14 actual connections across distinct numeric listeners.
- Desktop/mobile coverage screenshots visually inspected; readable without clipping.

Failure preserved: `.artifacts/builder-first-tests.log` records the old two-probe expectation failing `4 !== 2`. The original single-address regression now uses one DNS address; a separate six-probe test verifies multi-address behavior. UI helper’s initial PATH Node16 check failed with environment `EPERM`; bundled Node24 checks passed.

Changed scope: 17 tracked files under the product and its dedicated CI workflow, plus new `src/limits.mjs` and `test/multi-address.test.mjs`.

Limitations: sampling remains bounded and point-in-time; fixture inventories do not claim public DNS validation. Production DNS/pinning tests use instrumentation without public network contact. Independent verification and exact-candidate CI remain the lead’s next gates.
